import { Link } from "react-router-dom";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-neutral-900 text-neutral-400 font-body">
      <div className="container-site py-12">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {/* Tentang */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-full bg-brand-gold-500 flex items-center justify-center text-neutral-900 font-bold text-sm shrink-0">
                IPM
              </div>
              <span className="font-display font-bold text-white text-base">
                PW IPM Jawa Barat
              </span>
            </div>
            <p className="text-sm leading-relaxed max-w-sm">
              Pimpinan Wilayah Ikatan Pelajar Muhammadiyah Jawa Barat — pusat informasi resmi
              organisasi kepelajaran Muhammadiyah se-Jawa Barat.
            </p>
            {/* Media Sosial */}
            <div className="flex gap-3 mt-4">
              <a href="#" aria-label="Instagram PW IPM Jabar" className="p-2 rounded-lg hover:bg-white/10 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a href="#" aria-label="Facebook PW IPM Jabar" className="p-2 rounded-lg hover:bg-white/10 transition-colors min-h-[44px] min-w-[44px] flex items-center justify-center">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
            </div>
          </div>

          {/* Navigasi Cepat */}
          <div>
            <h3 className="font-display font-semibold text-white mb-4 text-sm uppercase tracking-wide">
              Navigasi
            </h3>
            <ul className="space-y-2 text-sm">
              {[
                { to: "/berita",    label: "Berita & Informasi" },
                { to: "/profil",    label: "Profil Kepengurusan" },
                { to: "/timeline",  label: "Program Kerja" },
                { to: "/pengaduan", label: "Pengaduan / Surat" },
              ].map(({ to, label }) => (
                <li key={to}>
                  <Link to={to} className="hover:text-white transition-colors">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Kontak */}
          <div>
            <h3 className="font-display font-semibold text-white mb-4 text-sm uppercase tracking-wide">
              Kontak
            </h3>
            <address className="not-italic text-sm space-y-2">
              <p>Jawa Barat, Indonesia</p>
              <p>
                <a href="mailto:ipmjabar@example.or.id" className="hover:text-white transition-colors">
                  ipmjabar@example.or.id
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
          <p>© {year} PW IPM Jawa Barat. Hak Cipta Dilindungi.</p>
          <p>Bidang Teknologi Informasi IPM Jabar</p>
        </div>
      </div>
    </footer>
  );
}
